package springbootsqlserverdb.springbootsqlserverdb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import springbootsqlserverdb.springbootsqlserverdb.domain.User;
import springbootsqlserverdb.springbootsqlserverdb.repo.UserRepository;

/**
 * Unit test for simple App.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserRepositoryTest {
	
	@Autowired
	private UserRepository userRepo;
	
	@Before
	public void setUp() throws Exception {
		User user1 = new User("Kumara" , 28);
		User user2 = new User("Vel" , 29);
		
		assertNotNull(user1.getUserId());
		assertNotNull(user2.getUserId());
		this.userRepo.save(user1);
		this.userRepo.save(user2);
		assertNotNull(user1.getUserId());
		assertNotNull(user2.getUserId());
		
	}
	
	@Test
	public void testFetchData() {
		User userA = userRepo.findByName("Vel");
		assertNotNull(userA);
		assertEquals(29, userA.getAge());
		
		Iterable<User> user = userRepo.findAll();
		int count = 0;
		for(User p : user) {
			count++;
		}
		assertEquals(2, count);
	}
	
}
