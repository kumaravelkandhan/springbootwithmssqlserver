package springbootsqlserverdb.springbootsqlserverdb.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import springbootsqlserverdb.springbootsqlserverdb.domain.User;
import springbootsqlserverdb.springbootsqlserverdb.service.UserService;

@Controller
@RequestMapping("/")
public class UserController {

	@Autowired
	private UserService userService;

	@RequestMapping
	public String viewHomePage(Model model) {
		List<User> listUsers = userService.listAll();
		System.out.println("user size  : " + listUsers.size());
		model.addAttribute("listUsers", listUsers);
		return "list-employee";
	}

	@RequestMapping(path = { "/edit", "/edit/{id}" })
	public String editEmployeeById(Model model, @PathVariable("id") Optional<Long> id) {
		if (id.isPresent()) {
			User user = userService.get(id.get());
			model.addAttribute("employee", user);
		}
		return "add-edit-employee";
	}

	@RequestMapping(path = "/createEmployee", method = RequestMethod.POST)
	public String createOrUpdateEmployee(User user) {
		userService.save(user);
		return "redirect:/";
	}

	@RequestMapping(path = "/delete/{id}")
	public String deleteEmployeeById(Model model, @PathVariable("id") Long id) throws Exception {
		userService.deleteEmployeeById(id);
		return "redirect:/";
	}
}
