package springbootsqlserverdb.springbootsqlserverdb.repo;

import org.springframework.data.repository.CrudRepository;

import springbootsqlserverdb.springbootsqlserverdb.domain.User;

public interface UserRepository extends CrudRepository<User, Integer> {
    User findByName(String name);
}
