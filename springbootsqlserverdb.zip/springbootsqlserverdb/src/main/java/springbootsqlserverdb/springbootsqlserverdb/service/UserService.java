package springbootsqlserverdb.springbootsqlserverdb.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springbootsqlserverdb.springbootsqlserverdb.domain.User;
import springbootsqlserverdb.springbootsqlserverdb.repo.UserRepository;

@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository userRepo;

	public List<User> listAll() {
		return userRepo.findAll();
	}

	public void save(User user) {
		userRepo.save(user);
	}

	public User get(long id) {
		return userRepo.findById(id).get();
	}

	public void delete(long id) {
		userRepo.deleteById(id);
	}

	public void deleteEmployeeById(Long id) throws Exception {
		Optional<User> employee = userRepo.findById(id);
		if (employee.isPresent()) {
			userRepo.deleteById(id);
		} else {
			throw new Exception("No employee record exist for given id");
		}
	}
}
